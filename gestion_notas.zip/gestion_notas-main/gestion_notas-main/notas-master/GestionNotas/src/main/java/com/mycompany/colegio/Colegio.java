/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.colegio;

import Views.Login;

/**
 *
 * @author NEW PC MDMS
 */
public class Colegio {

    public static void main(String[] args) {
        Login vLogin = new Login();
        vLogin.setLocationRelativeTo(null);
        vLogin.setVisible(true);
    }
}
