/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Interface;

import Models.AuthModel;

/**
 *
 * @author NEW PC MDMS
 * @param <T>
 */
public interface ILogin<T> {
    boolean iniciar_sesion(T objeto);
}
